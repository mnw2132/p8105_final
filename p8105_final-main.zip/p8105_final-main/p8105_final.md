p8105_final- Team registration and proposal
================
Mary Williams, Sarahy Martinez, Tanmayi Amanchi, Kaleb Frierson
2024-10-28

## The group members (names and UNIs)

Mary Williams, mnw2132 Sarahy Martinez, sjm2284 Tanmayi Amanchi, taa2158
Kaleb Frierson, kjf2152

## The tentative project title

## The motivation for this project

## The intended final products

## The anticipated data sources

## The planned analyses / visualizations / coding challenges

## The planned timeline
